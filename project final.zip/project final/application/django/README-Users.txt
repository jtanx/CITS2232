List of usernames and passwords, in username:password format.

Superuser:
ucadmin:ucadmin

Admin:
testadmin:testadmin

Users:
Mill:computer
HiAll123:computer
Extra:computer
Demo1:computer
Demo2:computer
Demo3:computer
Demo4:computer
