'''This can be run from idle. I'm using python27'''
import os, sys, re
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "unchained.settings")
from sportsrec.models import *
from django.utils import timezone



