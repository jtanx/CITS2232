INSERT INTO sportsrec_member VALUES(1, "Miles", "Edgworth", "something@website.com", "15 Mannikin Heights", "Milesy", "Milesy", "091280941", "Hi, my name is...

Who, my name is...

What, my name is...", 4);
INSERT INTO sportsrec_member VALUES(2, "Morn", "Ingstar", "something@website2.com", "10 Washington way", "Morn", "Morn", "87589281", "Hi, my name is...

Who, my name is...

What, my name is...", 4);
INSERT INTO sportsrec_member VALUES(3, "Mr", "Wright", "something@website3.com", "", "", "", "", "", 4);
INSERT INTO sportsrec_member VALUES(4, "Repo", "Man", "something@website4.com", "Something Somewhere", "", "", "", "", 4);
INSERT INTO sportsrec_member VALUES(5, "Last M.", "Standing", "something@website.com", "", "Alhambra", "", "", "", 4);
INSERT INTO sportsrec_member VALUES(6, "George", "Washington", "something@website2.com", "", "", "WashingtonPress", "", "", 4);
INSERT INTO sportsrec_member VALUES(7, "Something o.", "Other", "something@website3.com", "", "", "", "835789571", "The quick brown fox jumped over the lazy dog.", 5);
INSERT INTO sportsrec_member VALUES(8, "Annoying", "Git", "annoying@club.com", "", "", "", "", "The quick brown fox jumped over the lazy dog.", 5);
INSERT INTO sportsrec_member VALUES(9, "D.D.", "Fred", "horrible.movies@hollywood.com", "", "", "", "89256892", "", 5);
INSERT INTO sportsrec_member VALUES(10, "Ecks P.", "Slosive", "something@website4.com", "", "", "", "", "", 6);
INSERT INTO sportsrec_member VALUES(11, "De", "Mo", "demo1@demo.com", "", "", "", "", "", 7);
INSERT INTO sportsrec_member VALUES(12, "De", "mos", "demo2@demo.com", "", "", "", "", "", 8);
INSERT INTO sportsrec_member VALUES(13, "Alhambra", "Dedara", "demo3@demo.com", "", "", "", "", "", 9);
INSERT INTO sportsrec_member VALUES(14, "Ade", "Mod", "demo4@demo.com", "", "", "", "", "The quick brown fox jumps over the lazy dog.", 10);
INSERT INTO sportsrec_member VALUES(15, "Elan", "Greenheart", "demo4@demo.com", "", "", "", "", "", 10);
INSERT INTO sportsrec_clubtype VALUES(1, "Soccer", "A soccer club, or a club about soccer", 0);
INSERT INTO sportsrec_clubtype VALUES(2, "Hockey", "A hockey club, or a club about hockey", 0);
INSERT INTO sportsrec_clubtype VALUES(3, "AFL", "An AFL club, or a club about AFL", 0);
INSERT INTO sportsrec_clubtype VALUES(4, "Swimming", "A swimming club, or a club about swimming", 0);
INSERT INTO sportsrec_clubtype VALUES(5, "Basketball", "A basketball club, or a club about basketball", 0);
INSERT INTO sportsrec_clubtype VALUES(6, "Tennis", "A tennis club, or a club about tennis", 0);
INSERT INTO sportsrec_clubtype VALUES(7, "Rugby", "A rugby club, or a club about rugby", 0);
INSERT INTO sportsrec_clubtype VALUES(8, "Formula One", "A formula one racing club, or a club about formula one racing", 0);
INSERT INTO sportsrec_clubtype VALUES(9, "Gaming", "A gaming club, or a club about games", 0);
INSERT INTO sportsrec_clubtype VALUES(10, "Hunting", "A club about game hunting", 0);
INSERT INTO sportsrec_clubtype VALUES(11, "Cricket", "A cricket club, or a club about cricket", 0);
INSERT INTO sportsrec_clubtype VALUES(12, "Sailing", "A sailing club, or a club about sailing", 0);
INSERT INTO sportsrec_clubtype VALUES(13, "Recreation", "A recreation club, or a club about recreating", 0);
INSERT INTO sportsrec_clubtype VALUES(14, "Hobby", "A hobby club, or a club about hobbies", 0);
INSERT INTO sportsrec_clubtype VALUES(15, "Social", "A social club, or a club about socials", 0);
INSERT INTO sportsrec_clubtype VALUES(16, "Country", "A Country club, or a club about the country", 0);
INSERT INTO sportsrec_clubtype VALUES(17, "Dance", "A dance club, or a club about dancing.", 0);
INSERT INTO sportsrec_clubtype VALUES(18, "Other", "None of the above.", 0);
INSERT INTO sportsrec_clubtag VALUES(1, "Hi");
INSERT INTO sportsrec_clubtag VALUES(2, "Rap");
INSERT INTO sportsrec_clubtag VALUES(3, "zap");
INSERT INTO sportsrec_clubtag VALUES(4, "Breaking");
INSERT INTO sportsrec_clubtag VALUES(5, "the");
INSERT INTO sportsrec_clubtag VALUES(6, "Laws");
INSERT INTO sportsrec_clubtag VALUES(7, "of");
INSERT INTO sportsrec_clubtag VALUES(8, "Physics");
INSERT INTO sportsrec_clubtag VALUES(9, "Canning");
INSERT INTO sportsrec_clubtag VALUES(10, "bad");
INSERT INTO sportsrec_clubtag VALUES(11, "luck");
INSERT INTO sportsrec_clubtag VALUES(12, "One");
INSERT INTO sportsrec_clubtag VALUES(13, "Two");
INSERT INTO sportsrec_clubtag VALUES(14, "Three");
INSERT INTO sportsrec_clubtag VALUES(15, "Ice");
INSERT INTO sportsrec_clubtag VALUES(16, "Skating");
INSERT INTO sportsrec_clubtag VALUES(17, "soccer");
INSERT INTO sportsrec_clubtag VALUES(18, "Soccer");
INSERT INTO sportsrec_clubtag VALUES(19, "Hunting");
INSERT INTO sportsrec_clubtag VALUES(20, "AFL");
INSERT INTO sportsrec_clubtag VALUES(21, "Test");
INSERT INTO sportsrec_club VALUES(1, "Hi, My name is...", "Fairway, Perth", "-31.98242", "115.81564", 10, 0, "2013-10-18", 1, 1, "Hi, my name is...

Who, my name is...

What, my name is...", "Morn", "Temper", 2);
INSERT INTO sportsrec_club VALUES(2, "Electrical", "17 Mannikin Heights", "-32.1374", "115.81717", 18, 0, "2013-10-18", 1, 1, "The quick brown fox jumped over the lazy dog.", "Thunder", "", 1);
INSERT INTO sportsrec_club VALUES(3, "Thundermite", "40 Canning Hwy", "-31.9769", "115.8809", 9, 0, "2013-10-18", 1, 1, "The quick brown fox jumped over the lazy dog.", "", "Gorn", 1);
INSERT INTO sportsrec_club VALUES(4, "AnnoytheNeighbourhood", "34 Canning Highway", "-31.97662", "115.88116", 13, 0, "2013-10-18", 1, 8, "The quick brown fox jumped over the lazy dog.", "LiveToAnnoy", "", 7);
INSERT INTO sportsrec_club VALUES(5, "UWA Sport Club", "Mounts Bay Road", "-31.96757", "115.83857", 1, 0, "2013-10-18", 1, NULL, "The quick brown fox jumped over the lazy dog.", "Elonerth", "", 4);
INSERT INTO sportsrec_club VALUES(6, "Tiny Tina", "14 North Lake Road, Perth", "-32.033", "115.81601", 3, 0, "2013-10-18", 1, 10, "The quick brown fox jumped over the lazy dog.", "", "", 10);
INSERT INTO sportsrec_club VALUES(7, "Testadmin", "Honour Avenue, Perth", "-32.01632", "115.78807", 18, 0, "2013-10-19", 1, NULL, "The quick brown fox jumps over the lazy dog.", "", "", 5);
INSERT INTO sportsrec_club VALUES(8, "Another Club", "Rokeby Road, Perth", "-31.95202", "115.82401", 1, 0, "2013-10-19", 1, NULL, "The quick brown fox jumps over the lazy dog.", "", "", 9);
INSERT INTO sportsrec_club VALUES(9, "Demo", "1 Kwinana Freeway", "-32.27589", "115.84125", 11, 0, "2013-10-19", 1, NULL, "The quick brown fox jumps over the lazy dog.", "", "", 11);
INSERT INTO sportsrec_club VALUES(10, "Subiaco Sport Club", "Hay Street", "-31.94977", "115.84532", 2, 0, "2013-10-20", 1, NULL, "The quick brown fox jumps over the lazy dog.", "", "", 12);
INSERT INTO sportsrec_club_tags VALUES(1, 1, 1);
INSERT INTO sportsrec_club_tags VALUES(2, 1, 2);
INSERT INTO sportsrec_club_tags VALUES(3, 1, 19);
INSERT INTO sportsrec_club_tags VALUES(4, 2, 3);
INSERT INTO sportsrec_club_tags VALUES(5, 3, 4);
INSERT INTO sportsrec_club_tags VALUES(6, 3, 5);
INSERT INTO sportsrec_club_tags VALUES(7, 3, 6);
INSERT INTO sportsrec_club_tags VALUES(8, 3, 7);
INSERT INTO sportsrec_club_tags VALUES(9, 3, 8);
INSERT INTO sportsrec_club_tags VALUES(10, 4, 9);
INSERT INTO sportsrec_club_tags VALUES(11, 5, 10);
INSERT INTO sportsrec_club_tags VALUES(12, 5, 11);
INSERT INTO sportsrec_club_tags VALUES(13, 5, 17);
INSERT INTO sportsrec_club_tags VALUES(14, 6, 12);
INSERT INTO sportsrec_club_tags VALUES(15, 6, 13);
INSERT INTO sportsrec_club_tags VALUES(16, 6, 14);
INSERT INTO sportsrec_club_tags VALUES(17, 6, 20);
INSERT INTO sportsrec_club_tags VALUES(18, 7, 21);
INSERT INTO sportsrec_club_tags VALUES(19, 8, 18);
INSERT INTO sportsrec_club_tags VALUES(20, 10, 15);
INSERT INTO sportsrec_club_tags VALUES(21, 10, 16);
INSERT INTO sportsrec_membershipapplication VALUES(4, "2013-10-18", 10, 1, 1);
INSERT INTO sportsrec_membershipapplication VALUES(8, "2013-10-19", 8, 9, 1);
INSERT INTO sportsrec_membershipapplication VALUES(11, "2013-10-20", 9, 10, 1);
INSERT INTO sportsrec_membership VALUES(1, "2013-10-18", "2019-04-01", 2, 1);
INSERT INTO sportsrec_membership VALUES(2, "2013-10-18", "2013-01-01", 1, 1);
INSERT INTO sportsrec_membership VALUES(3, "2013-10-18", NULL, 1, 2);
INSERT INTO sportsrec_membership VALUES(4, "2013-10-18", "2018-01-05", 1, 3);
INSERT INTO sportsrec_membership VALUES(5, "2013-10-18", NULL, 7, 4);
INSERT INTO sportsrec_membership VALUES(6, "2013-10-18", NULL, 8, 4);
INSERT INTO sportsrec_membership VALUES(7, "2013-10-18", NULL, 8, 1);
INSERT INTO sportsrec_membership VALUES(8, "2013-10-18", NULL, 9, 4);
INSERT INTO sportsrec_membership VALUES(9, "2013-10-18", NULL, 7, 2);
INSERT INTO sportsrec_membership VALUES(11, "2013-10-18", "2013-04-03", 4, 5);
INSERT INTO sportsrec_membership VALUES(13, "2013-10-18", NULL, 2, 5);
INSERT INTO sportsrec_membership VALUES(14, "2013-10-18", NULL, 10, 3);
INSERT INTO sportsrec_membership VALUES(15, "2013-10-18", NULL, 10, 6);
INSERT INTO sportsrec_membership VALUES(16, "2013-10-19", NULL, 12, 6);
INSERT INTO sportsrec_membership VALUES(17, "2013-10-19", "2013-03-01", 13, 2);
INSERT INTO sportsrec_membership VALUES(18, "2013-10-19", "2013-01-01", 5, 7);
INSERT INTO sportsrec_membership VALUES(19, "2013-10-19", NULL, 6, 2);
INSERT INTO sportsrec_membership VALUES(20, "2013-10-19", NULL, 4, 7);
INSERT INTO sportsrec_membership VALUES(21, "2013-10-19", NULL, 6, 7);
INSERT INTO sportsrec_membership VALUES(22, "2013-10-19", NULL, 9, 8);
INSERT INTO sportsrec_membership VALUES(23, "2013-10-19", NULL, 7, 8);
INSERT INTO sportsrec_membership VALUES(24, "2013-10-19", NULL, 6, 8);
INSERT INTO sportsrec_membership VALUES(25, "2013-10-19", "2016-02-09", 11, 9);
INSERT INTO sportsrec_membership VALUES(26, "2013-10-19", NULL, 12, 9);
INSERT INTO sportsrec_membership VALUES(27, "2013-10-19", "2018-04-07", 13, 9);
INSERT INTO sportsrec_membership VALUES(28, "2013-10-19", NULL, 7, 9);
INSERT INTO sportsrec_membership VALUES(29, "2013-10-19", NULL, 9, 9);
INSERT INTO sportsrec_membership VALUES(30, "2013-10-19", "2019-01-02", 1, 9);
INSERT INTO sportsrec_membership VALUES(31, "2013-10-19", NULL, 5, 9);
INSERT INTO sportsrec_membership VALUES(32, "2013-10-19", NULL, 15, 4);
INSERT INTO sportsrec_membership VALUES(33, "2013-10-19", NULL, 14, 3);
INSERT INTO sportsrec_membership VALUES(34, "2013-10-20", NULL, 12, 10);
INSERT INTO sportsrec_membership VALUES(35, "2013-10-20", NULL, 7, 10);
INSERT INTO sportsrec_membership VALUES(36, "2013-10-20", NULL, 8, 10);
INSERT INTO sportsrec_membership VALUES(37, "2013-10-20", NULL, 1, 10);
INSERT INTO sportsrec_membership VALUES(38, "2013-10-20", NULL, 6, 10);
INSERT INTO sportsrec_membership VALUES(39, "2013-10-20", NULL, 12, 8);
