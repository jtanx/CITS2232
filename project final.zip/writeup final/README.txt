To run this Django Unchained web application:

===================================

1. Within Terminal or cmd, cd to the application/django directory

2. Call "python manage.py syncdb"
2.1 Say "no" to the question it asks you about creating super-users

3. Call "python manage.py runserver"

4. When that loads successfully, open a web browser and go to "http://localhost:8000"

Go nuts!
You can Login with testadmin/testadmin or testuser/testuser, 
representing the two different types of users, or Register your 
own end user if you prefer.

Other test logins for testing:
(Username:Password)
Mill:computer
HiAll123:computer
Extra:computer
Demo1:computer
Demo2:computer
Demo3:computer
Demo4:computer
